﻿using HashCodeCommon;

namespace _2017_Final
{
    internal class ProblemOutput
    {
        public MatrixCoordinate[] BackBoneCoordinates { get; set; }

        public MatrixCoordinate[] RouterCoordinates { get; set; }
    }
}