﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using _2018_Qualification;

namespace _2018_Qualification_Test
{
    [TestClass]
    public class ParserTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            Parser parser = new Parser();
        }
    }
}
