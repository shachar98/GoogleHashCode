﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2017_Qualification
{
    public class ProblemOutput
    {
		public Dictionary<CachedServer, List<Video>> ServerAssignments{ get; set; }
    }
}
