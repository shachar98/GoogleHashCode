﻿using System.Collections.Generic;

namespace _2017_Qualification
{
	public class ServerAssignment
	{
		public CachedServer Server { get; set; }
		public List<Video> Videos { get; set; }
	}
}