﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2015_Qualification
{
    public class ProblemOutput
    {
		public Dictionary<Server, ServerAllocation> _allocations { get; set; }

		public ProblemInput original_input { get; set; }
    }
}
