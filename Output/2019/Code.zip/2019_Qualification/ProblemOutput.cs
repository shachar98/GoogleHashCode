﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2019_Qualification
{
    public class ProblemOutput
    {
        public List<Slide> Slideshow { get; set; } = new List<Slide>();
    }
}
