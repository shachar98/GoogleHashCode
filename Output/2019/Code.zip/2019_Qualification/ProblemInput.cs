﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2019_Qualification
{
    public class ProblemInput
    {
        public List<Photo> Photos { get; set; } = new List<Photo>();
    }
}
